# Jenkinsfile examples

This directory contains example Jenkinsfiles written in Declarative Pipeline Syntax. 
