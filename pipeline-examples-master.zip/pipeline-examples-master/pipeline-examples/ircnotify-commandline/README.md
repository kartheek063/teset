# Synopsis
Send a notification to an IRC channel

# Background
The IRC protocol is simple enough that you can use a pipeline shell step and nc to send a message to an irc room.
You will need to customize the script to use the actual room, server, and authentication details.  
