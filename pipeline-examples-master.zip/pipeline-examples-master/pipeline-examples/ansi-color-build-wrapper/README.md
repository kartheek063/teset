# Synopsis

This shows usage of a simple build wrapper, specifically the
AnsiColor plugin, which adds ANSI coloring to the console output.
