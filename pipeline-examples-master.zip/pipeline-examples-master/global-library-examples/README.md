# Global library examples

This directory contains examples of how to extend Workflow using the global library on your Jenkins master.
