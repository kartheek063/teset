# Synopsis
An example of how to define a global function for the Workflow DSL on
your Jenkins master using the global CPS library.

# Credit

This comes from the [CloudBeers demo](https://github.com/cloudbeers/multibranch-demo).
